# Bagaimana Jika Membeli Emas 1 Gram per Bulan? (Remotion)

1080x1920, 30 FPS, 900 frame (30 detik).

    npm install
    npm start        # preview di Remotion Studio
    npm run build    # render ke out/emas-per-bulan.mp4

## Audio (opsional)
Taruh file di public/audio/ lalu ubah USE_AUDIO = true di src/config.ts:
music.mp3, narasi-1.mp3 ... narasi-5.mp3, sfx-tap.mp3, sfx-drop.mp3, sfx-flip.mp3, sfx-shine.mp3
Teks narasi ada di CAPTIONS (src/config.ts). Waktu SFX ada di src/Video.tsx.
