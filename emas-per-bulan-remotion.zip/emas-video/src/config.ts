export const FPS = 30;
export const W = 1080;
export const H = 1920;
export const TOTAL = 900; // 30 detik
export const OVERLAP = 10; // crossfade antar scene (frame)

// Scene: mulai & durasi (frame, tanpa overlap)
export const SCENES = [
  {from: 0, dur: 150},
  {from: 150, dur: 150},
  {from: 300, dur: 180},
  {from: 480, dur: 180},
  {from: 660, dur: 240},
];

// Ubah ke true setelah file audio ditaruh di public/audio/
// music.mp3, narasi-1.mp3 ... narasi-5.mp3, sfx-tap.mp3, sfx-drop.mp3, sfx-flip.mp3, sfx-shine.mp3
export const USE_AUDIO = false;

export const FONT =
  'Poppins, "Arial Rounded MT Bold", "Arial Black", system-ui, sans-serif';

export const CAPTIONS = [
  {a: 5, b: 70, t: 'Dika punya rencana sederhana.'},
  {a: 70, b: 148, t: 'Bagaimana kalau setiap bulan ia membeli satu gram emas?'},
  {a: 152, b: 225, t: 'Bulan pertama, ia berhasil mendapatkan emas pertamanya.'},
  {a: 225, b: 298, t: 'Lalu bulan kedua, ketiga, dan seterusnya.'},
  {a: 302, b: 360, t: 'Tapi ternyata tidak selalu mudah.'},
  {a: 360, b: 478, t: 'Harga emas berubah, sementara kebutuhan sehari-hari juga harus dipenuhi.'},
  {a: 482, b: 550, t: 'Beberapa kali ia harus menunda.'},
  {a: 550, b: 658, t: 'Namun, bulan demi bulan terus berlalu, dan koleksinya semakin bertambah.'},
  {a: 662, b: 780, t: 'Lima tahun kemudian, seluruh pembeliannya mencapai enam puluh gram emas.'},
  {a: 780, b: 892, t: 'Dari satu gram kecil setiap bulan, kini ia memiliki enam puluh gram emas.'},
];
