import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile, useCurrentFrame} from 'remotion';
import {OVERLAP, SCENES, USE_AUDIO} from './config';
import {Scene1, Scene2, Scene3, Scene4, Scene5} from './scenes';
import {Captions, lerp} from './ui';

const SceneFade: React.FC<{fadeIn: boolean; children: React.ReactNode}> = ({fadeIn, children}) => {
  const f = useCurrentFrame();
  const o = fadeIn ? lerp(f, [0, OVERLAP], [0, 1], (t) => t) : 1;
  return <AbsoluteFill style={{opacity: o}}>{children}</AbsoluteFill>;
};

const list = [Scene1, Scene2, Scene3, Scene4, Scene5];

// Frame global untuk SFX (sesuaikan bila timing diubah)
const SFX: {f: number; file: string}[] = [
  {f: 145, file: 'sfx-tap.mp3'},
  {f: 174, file: 'sfx-drop.mp3'},
  {f: 219, file: 'sfx-drop.mp3'},
  {f: 195, file: 'sfx-flip.mp3'},
  {f: 240, file: 'sfx-flip.mp3'},
  {f: 264, file: 'sfx-drop.mp3'},
  {f: 485, file: 'sfx-flip.mp3'},
  {f: 690, file: 'sfx-shine.mp3'},
];

export const Video: React.FC = () => (
  <AbsoluteFill style={{background: '#000'}}>
    {SCENES.map((s, i) => {
      const C = list[i];
      const start = i === 0 ? 0 : s.from - OVERLAP;
      const dur = i === 0 ? s.dur : s.dur + OVERLAP;
      return (
        <Sequence key={i} from={start} durationInFrames={dur}>
          <SceneFade fadeIn={i > 0}>
            <C />
          </SceneFade>
        </Sequence>
      );
    })}
    <Captions />
    {USE_AUDIO && (
      <>
        <Audio src={staticFile('audio/music.mp3')} volume={0.22} />
        {SCENES.map((s, i) => (
          <Sequence key={`n${i}`} from={s.from} durationInFrames={s.dur}>
            <Audio src={staticFile(`audio/narasi-${i + 1}.mp3`)} volume={1} />
          </Sequence>
        ))}
        {SFX.map((x, i) => (
          <Sequence key={`s${i}`} from={x.f} durationInFrames={45}>
            <Audio src={staticFile(`audio/${x.file}`)} volume={0.6} />
          </Sequence>
        ))}
      </>
    )}
  </AbsoluteFill>
);
