# Bagaimana Jika Membeli Emas 1 Gram per Bulan? (Remotion)

1080x1920, 30 FPS, 900 frame (30 detik).

    npm install
    npm start        # preview di Remotion Studio
    npm run build    # render ke out/emas-per-bulan.mp4

## Audio
- Musik & efek suara sudah ada di public/audio/ (dibuat oleh tools/synth_audio.py) dan aktif (USE_MUSIC_SFX = true).
- Narasi: jalankan
      pip install edge-tts mutagen
      python3 tools/narasi.py
  lalu ubah USE_NARRATION = true di src/config.ts. Ganti suara lewat VOICE di tools/narasi.py
  (id-ID-ArdiNeural pria, id-ID-GadisNeural wanita).
