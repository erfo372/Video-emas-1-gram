import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile, useCurrentFrame} from 'remotion';
import {OVERLAP, SCENES, USE_MUSIC_SFX, USE_NARRATION} from './config';
import {Scene1, Scene2, Scene3, Scene4, Scene5} from './scenes';
import {Captions, lerp} from './ui';

const SceneFade: React.FC<{fadeIn: boolean; children: React.ReactNode}> = ({fadeIn, children}) => {
  const f = useCurrentFrame();
  const o = fadeIn ? lerp(f, [0, OVERLAP], [0, 1], (t) => t) : 1;
  return <AbsoluteFill style={{opacity: o}}>{children}</AbsoluteFill>;
};

const list = [Scene1, Scene2, Scene3, Scene4, Scene5];

// Frame global untuk SFX (sesuaikan bila timing diubah)
const SFX: {f: number; file: string; dur: number}[] = [
  {f: 145, file: 'sfx-tap.wav', dur: 15},
  {f: 160, file: 'sfx-tap.wav', dur: 15},
  {f: 174, file: 'sfx-drop.wav', dur: 30},
  {f: 195, file: 'sfx-flip.wav', dur: 15},
  {f: 205, file: 'sfx-tap.wav', dur: 15},
  {f: 219, file: 'sfx-drop.wav', dur: 30},
  {f: 240, file: 'sfx-flip.wav', dur: 15},
  {f: 250, file: 'sfx-tap.wav', dur: 15},
  {f: 264, file: 'sfx-drop.wav', dur: 30},
  {f: 485, file: 'sfx-flipfast.wav', dur: 110},
  {f: 668, file: 'sfx-shine.wav', dur: 100},
];

export const Video: React.FC = () => (
  <AbsoluteFill style={{background: '#000'}}>
    {SCENES.map((s, i) => {
      const C = list[i];
      const start = i === 0 ? 0 : s.from - OVERLAP;
      const dur = i === 0 ? s.dur : s.dur + OVERLAP;
      return (
        <Sequence key={i} from={start} durationInFrames={dur}>
          <SceneFade fadeIn={i > 0}>
            <C />
          </SceneFade>
        </Sequence>
      );
    })}
    <Captions />
    {USE_MUSIC_SFX && (
      <>
        <Audio src={staticFile('audio/music.wav')} volume={USE_NARRATION ? 0.18 : 0.35} />
        {SFX.map((x, i) => (
          <Sequence key={`s${i}`} from={x.f} durationInFrames={x.dur}>
            <Audio src={staticFile(`audio/${x.file}`)} volume={0.6} />
          </Sequence>
        ))}
      </>
    )}
    {USE_NARRATION &&
      SCENES.map((s, i) => (
        <Sequence key={`n${i}`} from={s.from} durationInFrames={s.dur}>
          <Audio src={staticFile(`audio/narasi-${i + 1}.mp3`)} volume={1} />
        </Sequence>
      ))}
  </AbsoluteFill>
);
