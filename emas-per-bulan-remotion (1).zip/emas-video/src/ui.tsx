import React from 'react';
import {AbsoluteFill, Easing, interpolate, spring, useCurrentFrame} from 'remotion';
import {CAPTIONS, FONT, FPS, H, W} from './config';

export const ease = Easing.inOut(Easing.cubic);
const clampX = {extrapolateLeft: 'clamp' as const, extrapolateRight: 'clamp' as const};

export const lerp = (f: number, inp: number[], out: number[], easing: (t: number) => number = ease) =>
  interpolate(f, inp, out, {...clampX, easing});

export const lp = (f: number, inp: number[], pts: [number, number][]): [number, number] => [
  lerp(f, inp, pts.map((p) => p[0])),
  lerp(f, inp, pts.map((p) => p[1])),
];

export const pop = (f: number, start: number) =>
  f < start ? 0 : spring({frame: f - start, fps: FPS, config: {damping: 11, stiffness: 130}});

/* ---------- Kamera: smooth zoom & pan ---------- */
export const Cam: React.FC<{
  from: [number, number, number]; // [scale, fokusX, fokusY]
  to: [number, number, number];
  dur: number;
  children: React.ReactNode;
}> = ({from, to, dur, children}) => {
  const f = useCurrentFrame();
  const t = lerp(f, [0, dur], [0, 1]);
  const s = from[0] + (to[0] - from[0]) * t;
  const fx0 = from[1] + (to[1] - from[1]) * t;
  const fy0 = from[2] + (to[2] - from[2]) * t;
  const fx = Math.min(W - W / (2 * s), Math.max(W / (2 * s), fx0));
  const fy = Math.min(H - H / (2 * s), Math.max(H / (2 * s), fy0));
  return (
    <AbsoluteFill
      style={{transformOrigin: '0 0', transform: `translate(${W / 2 - fx * s}px, ${H / 2 - fy * s}px) scale(${s})`}}
    >
      {children}
    </AbsoluteFill>
  );
};

/* ---------- Emas ---------- */
export const GoldBarG: React.FC<{x: number; y: number; w: number; label?: string; rot?: number; opacity?: number}> = ({
  x, y, w, label = '1g', rot = 0, opacity = 1,
}) => (
  <g transform={`translate(${x},${y}) rotate(${rot}) scale(${w / 200}) translate(-100,-60)`} opacity={opacity}>
    <polygon points="45,2 155,2 188,46 12,46" fill="#ffe27a" stroke="#8a5a00" strokeWidth={5} strokeLinejoin="round" />
    <polygon points="12,46 188,46 198,116 2,116" fill="#f5b50a" stroke="#8a5a00" strokeWidth={5} strokeLinejoin="round" />
    <polygon points="20,52 70,52 60,110 12,110" fill="#fff" opacity={0.28} />
    {label ? (
      <text x="100" y="97" textAnchor="middle" fontSize="44" fontWeight={900} fill="#9a6200" fontFamily={FONT}>
        {label}
      </text>
    ) : null}
  </g>
);

export const GoldBar: React.FC<{w: number}> = ({w}) => (
  <svg width={w} height={w * 0.6} viewBox="0 0 200 120" style={{overflow: 'visible'}}>
    <GoldBarG x={100} y={60} w={200} />
  </svg>
);

/* ---------- Efek cahaya ---------- */
export const Rays: React.FC<{cx: number; cy: number; size: number; opacity?: number}> = ({cx, cy, size, opacity = 1}) => {
  const f = useCurrentFrame();
  const mask = 'radial-gradient(circle, #000 8%, transparent 68%)';
  return (
    <div
      style={{
        position: 'absolute',
        left: cx - size / 2,
        top: cy - size / 2,
        width: size,
        height: size,
        borderRadius: '50%',
        opacity,
        background: 'repeating-conic-gradient(rgba(255,226,120,0.55) 0deg 8deg, transparent 8deg 22deg)',
        WebkitMaskImage: mask,
        maskImage: mask,
        transform: `rotate(${f * 0.35}deg)`,
      }}
    />
  );
};

export const Glow: React.FC<{cx: number; cy: number; r: number; opacity?: number}> = ({cx, cy, r, opacity = 1}) => (
  <div
    style={{
      position: 'absolute',
      left: cx - r,
      top: cy - r,
      width: r * 2,
      height: r * 2,
      borderRadius: '50%',
      opacity,
      background: 'radial-gradient(circle, rgba(255,230,120,0.9) 0%, rgba(255,200,60,0.35) 45%, transparent 70%)',
    }}
  />
);

const rnd = (n: number) => {
  const v = Math.sin(n * 127.1 + 311.7) * 43758.5453;
  return v - Math.floor(v);
};

export const Sparkles: React.FC<{cx: number; cy: number; spread: number; n?: number; size?: number}> = ({
  cx, cy, spread, n = 12, size = 46,
}) => {
  const f = useCurrentFrame();
  return (
    <>
      {Array.from({length: n}).map((_, i) => {
        const tw = Math.max(0, Math.sin(f * 0.11 + i * 1.9));
        const s = size * (0.4 + rnd(i + 5) * 0.8) * tw;
        const x = cx + (rnd(i) - 0.5) * spread * 2;
        const y = cy + (rnd(i + 40) - 0.5) * spread * 1.4;
        return (
          <svg key={i} width={s} height={s} viewBox="-1 -1 2 2" style={{position: 'absolute', left: x - s / 2, top: y - s / 2}}>
            <path d="M0 -1 Q0.12 -0.12 1 0 Q0.12 0.12 0 1 Q-0.12 0.12 -1 0 Q-0.12 -0.12 0 -1Z" fill="#fff6c0" />
          </svg>
        );
      })}
    </>
  );
};

/* ---------- Kalender ---------- */
export const CalendarCard: React.FC<{
  x: number; y: number; w: number; label?: string; num: number | string; sub?: string; squash?: number;
}> = ({x, y, w, label = 'Bulan', num, sub, squash = 1}) => (
  <div
    style={{
      position: 'absolute', left: x, top: y, width: w, height: w * 1.25, background: '#fff',
      border: '6px solid #111', borderRadius: w * 0.1, fontFamily: FONT, textAlign: 'center', overflow: 'hidden',
      transform: `scaleY(${squash})`, transformOrigin: 'center bottom', boxShadow: '0 12px 0 rgba(0,0,0,0.18)',
    }}
  >
    <div style={{height: w * 0.2, background: '#7a4be0', borderBottom: '5px solid #111'}} />
    <div style={{fontSize: w * 0.17, fontWeight: 800, color: '#444', marginTop: w * 0.04}}>{label}</div>
    <div style={{fontSize: w * 0.46, fontWeight: 900, color: '#111', lineHeight: 1}}>{num}</div>
    {sub ? <div style={{fontSize: w * 0.13, fontWeight: 800, color: '#7a4be0', marginTop: w * 0.03}}>{sub}</div> : null}
  </div>
);

/* ---------- Teks ---------- */
export const Captions: React.FC = () => {
  const f = useCurrentFrame();
  const c = CAPTIONS.find((k) => f >= k.a && f < k.b);
  if (!c) return null;
  const o = lerp(f, [c.a, c.a + 6, c.b - 6, c.b], [0, 1, 1, 0], (t) => t);
  return (
    <div
      style={{
        position: 'absolute', left: 70, right: 70, bottom: 120, textAlign: 'center', opacity: o,
        fontFamily: FONT, fontWeight: 900, fontSize: 58, lineHeight: 1.2, color: '#fff',
        textShadow: '0 4px 0 #111, 4px 0 0 #111, -4px 0 0 #111, 0 -4px 0 #111, 3px 3px 0 #111, -3px -3px 0 #111, 3px -3px 0 #111, -3px 3px 0 #111',
      }}
    >
      {c.t}
    </div>
  );
};

export const Bubble: React.FC<{x: number; y: number; w: number; h: number; p: number; children: React.ReactNode}> = ({
  x, y, w, h, p, children,
}) => (
  <div
    style={{
      position: 'absolute', left: x, top: y, width: w, height: h, background: '#fff', border: '8px solid #111',
      borderRadius: h / 2, display: 'flex', alignItems: 'center', justifyContent: 'center',
      transform: `scale(${p})`, transformOrigin: 'left bottom', fontFamily: FONT,
    }}
  >
    {children}
  </div>
);

export const pileLayout = (n: number, cx: number, baseY: number, step: number, rowH: number) => {
  const rows = [12, 11, 10, 9, 8, 7, 3];
  const out: {x: number; y: number; i: number}[] = [];
  let i = 0;
  rows.forEach((c, r) => {
    for (let k = 0; k < c; k++) {
      if (i < n) out.push({x: cx + (k - (c - 1) / 2) * step, y: baseY - r * rowH, i});
      i++;
    }
  });
  return out;
};
