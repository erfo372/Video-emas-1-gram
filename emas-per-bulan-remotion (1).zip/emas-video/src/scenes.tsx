import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {Background} from './Background';
import {FONT, H, W} from './config';
import {Stickman} from './Stickman';
import {
  Bubble, CalendarCard, Cam, Glow, GoldBar, GoldBarG, Rays, Sparkles, lerp, lp, pileLayout, pop,
} from './ui';

/* ================= SCENE 1 ================= */
const Phone: React.FC = () => (
  <g>
    <rect x={-40} y={-118} width={80} height={140} rx={14} fill="#1c1c24" stroke="#000" strokeWidth={4} />
    <rect x={-33} y={-110} width={66} height={118} rx={8} fill="#fff4c4" />
    <GoldBarG x={0} y={-52} w={52} />
  </g>
);

export const Scene1: React.FC = () => {
  const f = useCurrentFrame();
  const L = 40, T = 760, S = 1.6;
  const idea = f >= 85;
  const bob = Math.sin(f * 0.12) * 4;
  const handL = lp(f, [0, 78, 100], [[188, 240], [188, 240], [96, 70]]);
  const pb = pop(f, 25);
  const pi = pop(f, 88);
  const pt = pop(f, 4);
  return (
    <AbsoluteFill>
      <Cam from={[1, 540, 960]} to={[1.1, 540, 1010]} dur={150}>
        <Background type="sky" />
        <Stickman x={L} y={T + bob} scale={S} expr={idea ? 'happy' : 'think'} handL={handL} handR={[322, 292]} holdR={<Phone />} look={idea ? 0 : 6} />
        {/* gelembung pikiran */}
        <Glow cx={800} cy={680} r={260} opacity={pb * (idea ? 0.4 : 1)} />
        <div style={{position: 'absolute', left: 565, top: 850, width: 40, height: 40, borderRadius: '50%', background: '#fff', border: '6px solid #111', transform: `scale(${pb})`}} />
        <div style={{position: 'absolute', left: 520, top: 905, width: 26, height: 26, borderRadius: '50%', background: '#fff', border: '5px solid #111', transform: `scale(${pb})`}} />
        <div style={{position: 'absolute', left: 590, top: 520, width: 420, height: 310, borderRadius: 160, background: '#fff', border: '8px solid #111', display: 'flex', alignItems: 'center', justifyContent: 'center', transform: `scale(${pb})`, opacity: idea ? 0.0 : 1}}>
          <GoldBar w={240} />
        </div>
        {/* ide: 1g / Bulan */}
        <Bubble x={620} y={560} w={400} h={190} p={pi}>
          <div style={{width: 96, height: 104, background: '#fff', border: '6px solid #111', borderRadius: 14, overflow: 'hidden', marginRight: 22}}>
            <div style={{height: 28, background: '#e8534a', borderBottom: '5px solid #111'}} />
            <div style={{fontSize: 52, fontWeight: 900, color: '#2e9e4f', textAlign: 'center', lineHeight: '66px'}}>✓</div>
          </div>
          <div style={{fontSize: 54, fontWeight: 900, color: '#111', lineHeight: 1.05}}>1g /<br />Bulan</div>
        </Bubble>
        {idea && (
          <svg width={W} height={H} style={{position: 'absolute', left: 0, top: 0, opacity: pi}}>
            <path d="M120 760 L150 700 M220 720 L235 650 M300 740 L350 690" stroke="#ffc928" strokeWidth={14} strokeLinecap="round" />
          </svg>
        )}
      </Cam>
      {/* judul */}
      <div style={{position: 'absolute', left: 0, right: 0, top: 110, textAlign: 'center', fontFamily: FONT, fontWeight: 900, transform: `scale(${0.7 + 0.3 * pt})`, opacity: Math.min(1, pt)}}>
        <div style={{fontSize: 74, color: '#fff', WebkitTextStroke: '10px #111', paintOrder: 'stroke fill'}}>Bagaimana Jika</div>
        <div style={{fontSize: 118, color: '#ffd21f', WebkitTextStroke: '12px #111', paintOrder: 'stroke fill', lineHeight: 1.05}}>Membeli Emas</div>
        <div style={{display: 'inline-block', background: '#16161d', borderRadius: 24, padding: '4px 36px 10px', fontSize: 84, color: '#fff', transform: 'rotate(-2deg)', marginTop: 8}}>1 Gram per Bulan?</div>
      </div>
    </AbsoluteFill>
  );
};

/* ================= SCENE 2 ================= */
export const Scene2: React.FC = () => {
  const f = useCurrentFrame();
  const L = 200, T = 640, S = 1.5;
  const drops = [20, 65, 110];
  const rest: [number, number] = [300, 400];
  const jar: [number, number] = [360, 313];
  const toScreen = (p: [number, number]): [number, number] => [L + p[0] * S, T + p[1] * S];

  let handR = rest;
  let carry = false;
  let fall = -1;
  drops.forEach((t) => {
    if (f >= t && f < t + 28) {
      handR = lp(f, [t, t + 14, t + 28], [rest, jar, rest]);
      carry = f < t + 14;
    }
    if (f >= t + 14 && f < t + 26) fall = lerp(f, [t + 14, t + 26], [0, 1]);
  });
  const count = drops.filter((t) => f >= t + 26).length;
  const hs = toScreen(handR);
  const fallIdx = drops.filter((t) => f >= t + 26).length;
  const month = f < 55 ? 1 : f < 100 ? 2 : 3;
  const flipAt = f < 100 ? 55 : 100;
  const ft = lerp(f - flipAt, [0, 10], [0, 1], (t) => t);
  const flipping = f >= 55 && ft < 1;
  const squash = flipping ? Math.abs(Math.cos(ft * Math.PI)) : 1;
  const shown = flipping && ft < 0.5 ? month - 1 : month;
  const toast = drops.map((t) => lerp(f, [t - 8, t, t + 30, t + 40], [0, 1, 1, 0], (x) => x));
  return (
    <AbsoluteFill>
      <Cam from={[1, 540, 1000]} to={[1.15, 600, 1150]} dur={150}>
        <Background type="room" />
        <Stickman x={L} y={T} scale={S} half expr={f < 14 ? 'neutral' : 'happy'} handR={handR} handL={[120, 420]} />
        <svg width={W} height={H} style={{position: 'absolute', left: 0, top: 0}}>
          {/* toples */}
          {Array.from({length: count}).map((_, i) => (
            <GoldBarG key={i} x={745 + (i % 2 ? 14 : -14)} y={1290 - i * 42} w={130} rot={i % 2 ? 6 : -5} />
          ))}
          <rect x={620} y={1120} width={250} height={215} rx={30} fill="rgba(255,255,255,0.38)" stroke="#111" strokeWidth={8} />
          <rect x={608} y={1098} width={274} height={34} rx={14} fill="#d9dcef" stroke="#111" strokeWidth={7} />
          {/* meja */}
          <rect x={-10} y={1335} width={W + 20} height={600} fill="#8b5a2b" stroke="#111" strokeWidth={8} />
          <rect x={-10} y={1335} width={W + 20} height={30} fill="#a8733c" stroke="#111" strokeWidth={6} />
          {/* emas jatuh & dibawa */}
          {fall >= 0 && <GoldBarG x={745} y={1100 + fall * (1290 - fallIdx * 42 - 1100)} w={130} />}
          {carry && <GoldBarG x={hs[0]} y={hs[1] - 30} w={130} rot={-8} />}
        </svg>
        <CalendarCard x={895} y={1120} w={150} num={shown} squash={squash} />
        {toast.map((o, i) => (
          <div key={i} style={{position: 'absolute', left: 150, top: 470 - o * 30, opacity: o, background: '#fff', border: '6px solid #111', borderRadius: 30, padding: '14px 30px', fontFamily: FONT, fontWeight: 900, fontSize: 46, color: '#2e9e4f', display: i === (f < 60 ? 0 : f < 105 ? 1 : 2) ? 'block' : 'none'}}>
            ✓ +1g
          </div>
        ))}
        <Sparkles cx={745} cy={1180} spread={160} n={6} size={40} />
      </Cam>
    </AbsoluteFill>
  );
};

/* ================= SCENE 3 ================= */
const PTS = [250, 190, 260, 130, 210, 90, 170, 60];
export const Scene3: React.FC = () => {
  const f = useCurrentFrame();
  const L = 20, T = 980, S = 1.4;
  const prog = lerp(f, [10, 120], [0, 1]);
  const d = PTS.map((y, i) => `${i ? 'L' : 'M'}${i * 120} ${y}`).join(' ');
  const idx = prog * (PTS.length - 1);
  const i0 = Math.min(PTS.length - 2, Math.floor(idx));
  const dx = (i0 + (idx - i0)) * 120;
  const dy = PTS[i0] + (PTS[i0 + 1] - PTS[i0]) * (idx - i0);
  const scratch: [number, number] = [292 + Math.sin(f * 0.5) * 7, 128 + Math.cos(f * 0.5) * 5];
  const handR = lp(f, [0, 30], [[300, 400], scratch]);
  const rising = (idx % 2) < 1;
  const cards = [
    {t: 'Makan', c: '#ff8a3d'},
    {t: 'Transport', c: '#4a90e8'},
    {t: 'Listrik', c: '#f5b50a'},
  ];
  return (
    <AbsoluteFill>
      <Cam from={[1, 540, 960]} to={[1.08, 560, 1050]} dur={180}>
        <Background type="room" />
        <div style={{position: 'absolute', left: 60, top: 380, width: 960, height: 540, background: 'rgba(20,24,50,0.94)', border: '8px solid #111', borderRadius: 40, boxShadow: '0 14px 0 rgba(0,0,0,0.25)', opacity: pop(f, 0), transform: `scale(${0.85 + 0.15 * pop(f, 0)})`}}>
          <div style={{position: 'absolute', left: 40, top: 26, fontFamily: FONT, fontWeight: 900, fontSize: 48, color: '#ffd21f'}}>Harga Emas / gram</div>
          <div style={{position: 'absolute', right: 40, top: 26, fontFamily: FONT, fontWeight: 900, fontSize: 48, color: rising ? '#4cd964' : '#ff5a5a'}}>{rising ? '▲ naik' : '▼ turun'}</div>
          <svg width={880} height={360} viewBox="-10 0 900 340" style={{position: 'absolute', left: 40, top: 130, overflow: 'visible'}}>
            {[0, 1, 2, 3].map((g) => <line key={g} x1={0} x2={840} y1={40 + g * 85} y2={40 + g * 85} stroke="#fff" opacity={0.15} strokeWidth={3} />)}
            <path d={d} pathLength={1} fill="none" stroke="#ffc928" strokeWidth={12} strokeLinecap="round" strokeLinejoin="round" strokeDasharray={1} strokeDashoffset={1 - prog} />
            <circle cx={dx} cy={dy} r={16 + Math.sin(f * 0.3) * 3} fill="#fff6c0" stroke="#ffc928" strokeWidth={6} />
          </svg>
        </div>
        <Stickman x={L} y={T} scale={S} expr={f < 30 ? 'shock' : 'worry'} handR={handR} handL={[110, 420]} look={f > 40 ? 8 : 0} />
        {/* tanda tanya */}
        {[0, 1, 2].map((i) => (
          <div key={i} style={{position: 'absolute', left: 150 + i * 120, top: 880 - Math.sin(f * 0.1 + i) * 14 - i * 20, fontFamily: FONT, fontWeight: 900, fontSize: 90, color: '#fff', WebkitTextStroke: '8px #111', paintOrder: 'stroke fill', transform: `scale(${pop(f, 40 + i * 12)})`}}>?</div>
        ))}
        {cards.map((c, i) => {
          const p = pop(f, 50 + i * 22);
          return (
            <div key={c.t} style={{position: 'absolute', left: 610 + (1 - p) * 500, top: 1010 + i * 200, width: 430, height: 160, background: '#fff', border: '7px solid #111', borderRadius: 34, display: 'flex', alignItems: 'center', fontFamily: FONT, fontWeight: 900, fontSize: 54, color: '#111', boxShadow: '0 10px 0 rgba(0,0,0,0.2)'}}>
              <div style={{width: 96, height: 96, borderRadius: '50%', background: c.c, border: '6px solid #111', margin: '0 26px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 52}}>
                {i === 0 ? '🍚' : i === 1 ? '🚌' : '⚡'}
              </div>
              {c.t}
            </div>
          );
        })}
      </Cam>
    </AbsoluteFill>
  );
};

/* ================= SCENE 4 ================= */
export const Scene4: React.FC = () => {
  const f = useCurrentFrame();
  const m = lerp(f, [0, 35, 60, 95, 120, 170], [1, 20, 20, 42, 42, 60], (t) => t);
  const n = Math.min(60, Math.max(1, Math.floor(m)));
  const frac = m - Math.floor(m);
  const stalled = (f > 35 && f < 60) || (f > 95 && f < 120);
  const squash = 1 - 0.28 * Math.sin(frac * Math.PI);
  const bars = pileLayout(n, 700, 1560, 56, 34);
  const sc = 1.1;
  return (
    <AbsoluteFill>
      <Cam from={[1, 540, 980]} to={[1.1, 620, 1000]} dur={180}>
        <Background type="sunset" shift={-f * 3} />
        <CalendarCard x={330} y={230} w={420} num={n} sub={`Tahun ${Math.ceil(n / 12)}`} squash={squash} />
        {stalled && (
          <div style={{position: 'absolute', left: 150, top: 560, fontFamily: FONT, fontWeight: 900, fontSize: 64, color: '#fff', WebkitTextStroke: '9px #111', paintOrder: 'stroke fill', transform: `rotate(-5deg) scale(${pop(f, f < 80 ? 36 : 96)})`}}>
            Ditunda...
          </div>
        )}
        <Stickman x={-30} y={950} scale={sc} expr={stalled ? 'worry' : n > 40 ? 'happy' : 'neutral'} walk={stalled ? undefined : f * 0.35} handL={[100, 430]} handR={[300, 430]} />
        <svg width={W} height={H} style={{position: 'absolute', left: 0, top: 0}}>
          {bars.map((b) => {
            
            return <GoldBarG key={b.i} x={b.x} y={b.y} w={52} label="" opacity={1} rot={(b.i % 3) - 1} />;
          })}
        </svg>
        <div style={{position: 'absolute', left: 520, top: 1130, width: 360, textAlign: 'center', fontFamily: FONT, fontWeight: 900, fontSize: 66, color: '#ffe27a', WebkitTextStroke: '9px #111', paintOrder: 'stroke fill'}}>{n} gram</div>
        <Sparkles cx={700} cy={1400} spread={330} n={10} size={44} />
      </Cam>
    </AbsoluteFill>
  );
};

/* ================= SCENE 5 ================= */
export const Scene5: React.FC = () => {
  const f = useCurrentFrame();
  const open = lerp(f, [20, 50], [0, 1]);
  const bars = pileLayout(60, 540, 1430, 80, 46);
  const num = Math.round(lerp(f, [150, 200], [0, 60]));
  const pt = pop(f, 150);
  const joy = f >= 50;
  const up = lp(f, [40, 70], [[110, 400], [70, 40]]);
  const upR = lp(f, [40, 70], [[290, 400], [330, 40]]);
  return (
    <AbsoluteFill>
      <Background type="gold" />
      <Cam from={[1.35, 540, 1500]} to={[1, 540, 960]} dur={140}>
        <Rays cx={540} cy={1400} size={2000} opacity={open} />
        <Glow cx={540} cy={1350} r={700} opacity={open * 0.8} />
        <Stickman x={340} y={655} scale={1.1} half expr={joy ? 'joy' : 'shock'} handL={up} handR={upR} />
        <svg width={W} height={H} style={{position: 'absolute', left: 0, top: 0}}>
          {/* tutup peti (terbuka, di belakang) */}
          <rect x={90} y={1360 - open * 160} width={900} height={100 - open * 10} rx={20} fill={open > 0.5 ? '#6b3f1a' : '#a8733c'} stroke="#111" strokeWidth={8} />
          {bars.map((b) => {
            const p = pop(f, 32 + b.i * 1.6);
            return <GoldBarG key={b.i} x={b.x} y={b.y + (1 - p) * 70} w={76} label="" opacity={Math.min(1, p)} rot={(b.i % 3) - 1} />;
          })}
          {/* badan peti */}
          <rect x={70} y={1440} width={940} height={270} rx={26} fill="#a8733c" stroke="#111" strokeWidth={9} />
          <rect x={70} y={1440} width={940} height={50} rx={22} fill="#c68a4a" stroke="#111" strokeWidth={7} />
          <rect x={490} y={1470} width={100} height={110} rx={16} fill="#ffd21f" stroke="#111" strokeWidth={7} />
          <circle cx={540} cy={1520} r={14} fill="#111" />
        </svg>
        <Sparkles cx={540} cy={1250} spread={480} n={18} size={64} />
      </Cam>
      {/* teks akhir */}
      <div style={{position: 'absolute', left: 90, right: 90, top: 190, padding: '34px 20px 40px', borderRadius: 48, background: 'rgba(22,22,29,0.92)', border: '8px solid #ffd21f', textAlign: 'center', fontFamily: FONT, fontWeight: 900, transform: `scale(${0.6 + 0.4 * pt})`, opacity: Math.min(1, pt)}}>
        <div style={{fontSize: 130, color: '#ffd21f', lineHeight: 1.05}}>{num} GRAM EMAS</div>
        <div style={{fontSize: 44, color: '#fff', marginTop: 10}}>5 TAHUN • 1 GRAM PER BULAN</div>
      </div>
    </AbsoluteFill>
  );
};
