import React from 'react';
import {useCurrentFrame} from 'remotion';

export type Expr = 'neutral' | 'think' | 'happy' | 'joy' | 'worry' | 'shock';

type Pt = [number, number];
type Props = {
  x: number;
  y: number;
  scale?: number;
  expr?: Expr;
  handL?: Pt;
  handR?: Pt;
  holdL?: React.ReactNode;
  holdR?: React.ReactNode;
  walk?: number; // fase langkah (radian); kosong = berdiri
  half?: boolean; // tanpa kaki (duduk / di balik meja)
  look?: number; // geser mata
};

const INK = '#111';
const SH_L: Pt = [155, 285];
const SH_R: Pt = [245, 285];

const ik = (s: Pt, t: Pt, side: 'L' | 'R', l1 = 95, l2 = 85) => {
  let dx = t[0] - s[0];
  let dy = t[1] - s[1];
  let d = Math.max(1, Math.hypot(dx, dy));
  const maxd = l1 + l2 - 0.5;
  if (d > maxd) {
    dx *= maxd / d;
    dy *= maxd / d;
    d = maxd;
  }
  const a = (l1 * l1 - l2 * l2 + d * d) / (2 * d);
  const h = Math.sqrt(Math.max(0, l1 * l1 - a * a));
  const ux = dx / d;
  const uy = dy / d;
  const c1 = {x: s[0] + ux * a - uy * h, y: s[1] + uy * a + ux * h};
  const c2 = {x: s[0] + ux * a + uy * h, y: s[1] + uy * a - ux * h};
  const pick = side === 'L' ? (c1.x < c2.x ? c1 : c2) : c1.x > c2.x ? c1 : c2;
  return {ex: pick.x, ey: pick.y, hx: s[0] + dx, hy: s[1] + dy};
};

const Face: React.FC<{expr: Expr; blink: boolean; look: number}> = ({expr, blink, look}) => {
  const sw = {stroke: INK, strokeWidth: 8, fill: 'none', strokeLinecap: 'round' as const, strokeLinejoin: 'round' as const};
  const eyes = (ry: number) => (
    <>
      <ellipse cx={165 + look} cy={142} rx={9} ry={blink ? 2 : ry} fill={INK} />
      <ellipse cx={235 + look} cy={142} rx={9} ry={blink ? 2 : ry} fill={INK} />
    </>
  );
  switch (expr) {
    case 'think':
      return (
        <g>
          {eyes(18)}
          <path d="M143 108 L186 118 M257 108 L214 118" {...sw} />
          <path d="M184 196 Q200 187 216 198" {...sw} />
        </g>
      );
    case 'happy':
      return (
        <g>
          <path d="M146 150 Q165 118 184 150 M216 150 Q235 118 254 150" {...sw} />
          <path d="M168 178 Q200 240 232 178 Z" fill="#e8334a" stroke={INK} strokeWidth={6} strokeLinejoin="round" />
          <path d="M184 205 Q200 195 216 205" fill="#ff8a98" />
        </g>
      );
    case 'joy':
      return (
        <g>
          <path d="M148 120 L186 142 L148 164 M252 120 L214 142 L252 164" {...sw} />
          <path d="M158 172 Q200 270 242 172 Z" fill="#e8334a" stroke={INK} strokeWidth={6} strokeLinejoin="round" />
          <path d="M180 218 Q200 202 220 218 Q200 236 180 218Z" fill="#ff8a98" />
        </g>
      );
    case 'worry':
      return (
        <g>
          {eyes(17)}
          <path d="M142 120 L186 100 M258 120 L214 100" {...sw} />
          <path d="M178 204 Q200 182 222 204" {...sw} />
          <path d="M296 70 Q282 100 296 108 Q312 100 296 70Z" fill="#6ec6ff" stroke={INK} strokeWidth={4} />
        </g>
      );
    case 'shock':
      return (
        <g>
          <circle cx={165 + look} cy={140} r={15} fill="#fff" stroke={INK} strokeWidth={6} />
          <circle cx={165 + look} cy={140} r={5} fill={INK} />
          <circle cx={235 + look} cy={140} r={15} fill="#fff" stroke={INK} strokeWidth={6} />
          <circle cx={235 + look} cy={140} r={5} fill={INK} />
          <ellipse cx={200} cy={200} rx={15} ry={21} fill="#e8334a" stroke={INK} strokeWidth={6} />
        </g>
      );
    default:
      return (
        <g>
          {eyes(18)}
          <path d="M180 190 Q200 206 220 190" {...sw} />
        </g>
      );
  }
};

export const Stickman: React.FC<Props> = ({
  x,
  y,
  scale = 1,
  expr = 'neutral',
  handL = [105, 430],
  handR = [295, 430],
  holdL,
  holdR,
  walk,
  half = false,
  look = 0,
}) => {
  const f = useCurrentFrame();
  const blink = f % 96 < 4;
  const L = ik(SH_L, handL, 'L');
  const R = ik(SH_R, handR, 'R');
  const a = walk === undefined ? 0 : Math.sin(walk) * 28;
  const leg = (hx: number, ang: number) => {
    const fx = hx + Math.sin((ang * Math.PI) / 180) * 168;
    const fy = 432 + Math.cos((ang * Math.PI) / 180) * 168;
    return (
      <g>
        <line x1={hx} y1={432} x2={fx} y2={fy} stroke={INK} strokeWidth={12} strokeLinecap="round" />
        <ellipse cx={fx + 10} cy={fy + 6} rx={24} ry={11} fill="#2b4fa3" stroke={INK} strokeWidth={5} />
      </g>
    );
  };
  const line = (e: {ex: number; ey: number; hx: number; hy: number}, s: Pt) => (
    <path d={`M${s[0]} ${s[1]} L${e.ex} ${e.ey} L${e.hx} ${e.hy}`} stroke={INK} strokeWidth={12} strokeLinecap="round" strokeLinejoin="round" fill="none" />
  );
  const hand = (h: {hx: number; hy: number}) => (
    <circle cx={h.hx} cy={h.hy} r={19} fill="#fff" stroke={INK} strokeWidth={6} />
  );
  return (
    <svg
      viewBox="0 0 400 640"
      style={{position: 'absolute', left: x, top: y, width: 400 * scale, height: 640 * scale, overflow: 'visible'}}
    >
      {/* ransel */}
      <rect x={120} y={258} width={78} height={150} rx={30} fill="#2b4fa3" stroke={INK} strokeWidth={7} />
      {!half && leg(172, a)}
      {!half && leg(228, -a)}
      {/* badan */}
      <path d="M150 262 Q200 244 250 262 L264 436 Q200 450 136 436 Z" fill="#fff" stroke={INK} strokeWidth={8} strokeLinejoin="round" />
      {/* kepala */}
      <circle cx={200} cy={140} r={112} fill="#fff" stroke={INK} strokeWidth={9} />
      <Face expr={expr} blink={blink} look={look} />
      {/* lengan */}
      {line(L, SH_L)}
      {line(R, SH_R)}
      <g transform={`translate(${L.hx},${L.hy})`}>{holdL}</g>
      <g transform={`translate(${R.hx},${R.hy})`}>{holdR}</g>
      {hand(L)}
      {hand(R)}
    </svg>
  );
};
