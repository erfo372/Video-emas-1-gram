import React from 'react';
import {AbsoluteFill} from 'remotion';
import {H, W} from './config';

export type BgType = 'sky' | 'room' | 'sunset' | 'gold';

export const Background: React.FC<{type: BgType; shift?: number}> = ({type, shift = 0}) => {
  if (type === 'gold') {
    return <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 72%, #ffe27a 0%, #d98a00 48%, #3d2100 100%)'}} />;
  }
  const grad: Record<string, string> = {
    sky: 'linear-gradient(#4aa8ff, #c4e8ff 70%, #dff3ff)',
    room: 'linear-gradient(#9aa6d8, #c9d0ee)',
    sunset: 'linear-gradient(#5b4aa8 0%, #e8708a 45%, #ffb35c 75%, #ffd98a)',
  };
  return (
    <AbsoluteFill style={{background: grad[type]}}>
      <svg width={W} height={H} style={{position: 'absolute', left: 0, top: 0}}>
        {type === 'sky' && (
          <g>
            <ellipse cx={780} cy={300} rx={170} ry={55} fill="#fff" opacity={0.9} />
            <ellipse cx={880} cy={270} rx={110} ry={50} fill="#fff" opacity={0.9} />
            <ellipse cx={200} cy={520} rx={140} ry={42} fill="#fff" opacity={0.85} />
            <rect x={-20} y={420} width={560} height={900} fill="#f1d7a8" stroke="#111" strokeWidth={6} />
            <rect x={-20} y={380} width={600} height={60} fill="#e8793a" stroke="#111" strokeWidth={6} />
            {[0, 1, 2, 3].map((r) =>
              [0, 1, 2].map((c) => (
                <rect key={`${r}${c}`} x={20 + c * 170} y={480 + r * 190} width={120} height={120} fill="#8fd0ff" stroke="#111" strokeWidth={5} />
              ))
            )}
            <rect x={900} y={820} width={40} height={400} fill="#8a5a2b" stroke="#111" strokeWidth={5} />
            <circle cx={920} cy={760} r={150} fill="#4fb85a" stroke="#111" strokeWidth={6} />
            <circle cx={1010} cy={830} r={100} fill="#62c96c" stroke="#111" strokeWidth={6} />
            <rect x={0} y={1500} width={W} height={420} fill="#74c765" />
          </g>
        )}
        {type === 'room' && (
          <g>
            <rect x={0} y={1500} width={W} height={420} fill="#7d6a58" />
            <rect x={640} y={330} width={300} height={380} fill="#8fd0ff" stroke="#111" strokeWidth={8} />
            <path d="M640 520 L940 520 M790 330 L790 710" stroke="#111" strokeWidth={6} />
            <rect x={-10} y={620} width={230} height={14} fill="#8a5a2b" stroke="#111" strokeWidth={5} />
            {[0, 1, 2, 3].map((i) => (
              <rect key={i} x={10 + i * 48} y={520} width={38} height={100} fill={['#e8534a', '#4a90e8', '#f5b50a', '#4fb85a'][i]} stroke="#111" strokeWidth={4} />
            ))}
            <rect x={-10} y={940} width={230} height={14} fill="#8a5a2b" stroke="#111" strokeWidth={5} />
            {[0, 1, 2].map((i) => (
              <rect key={i} x={20 + i * 55} y={840} width={44} height={100} fill={['#9b59d0', '#4fb85a', '#e8534a'][i]} stroke="#111" strokeWidth={4} />
            ))}
          </g>
        )}
        {type === 'sunset' && (
          <g transform={`translate(${shift},0)`}>
            <circle cx={820} cy={1050} r={190} fill="#fff1b0" opacity={0.9} />
            {Array.from({length: 14}).map((_, i) => {
              const h = 320 + ((i * 97) % 5) * 90;
              return <rect key={i} x={-300 + i * 150} y={1610 - h} width={120} height={h} fill={i % 2 ? '#4a3a8a' : '#3b2f78'} opacity={0.85} />;
            })}
            <rect x={-400} y={1610} width={W + 800} height={400} fill="#3a2b66" />
          </g>
        )}
      </svg>
    </AbsoluteFill>
  );
};
