"""Membuat suara narasi Indonesia (gratis) dengan edge-tts.
Jalankan di Codespaces (butuh internet):
    pip install edge-tts mutagen
    python3 tools/narasi.py
Hasil: public/audio/narasi-1.mp3 ... narasi-5.mp3
Kecepatan bicara otomatis dinaikkan bila narasi lebih panjang dari scene-nya."""
import asyncio
import edge_tts
from mutagen.mp3 import MP3

VOICE = "id-ID-ArdiNeural"  # suara pria. Alternatif wanita: id-ID-GadisNeural
OUT = "public/audio/"

# (teks, durasi scene dalam detik)
SCENES = [
    ("Dika punya rencana sederhana. Bagaimana kalau setiap bulan ia membeli satu gram emas?", 5),
    ("Bulan pertama, ia berhasil mendapatkan emas pertamanya. Lalu bulan kedua, ketiga, dan seterusnya.", 5),
    ("Tapi ternyata tidak selalu mudah. Harga emas berubah, sementara kebutuhan sehari-hari juga harus dipenuhi.", 6),
    ("Beberapa kali ia harus menunda. Namun, bulan demi bulan terus berlalu, dan koleksinya semakin bertambah.", 6),
    ("Lima tahun kemudian, seluruh pembeliannya mencapai enam puluh gram emas. Dari satu gram kecil setiap bulan, kini ia memiliki enam puluh gram emas.", 8),
]
RATES = ["+0%", "+10%", "+20%", "+30%", "+40%"]


async def make(i, text, limit):
    path = f"{OUT}narasi-{i}.mp3"
    for r in RATES:
        await edge_tts.Communicate(text, VOICE, rate=r).save(path)
        dur = MP3(path).info.length
        print(f"narasi-{i}: rate {r} -> {dur:.2f}s (batas {limit - 0.3:.1f}s)")
        if dur <= limit - 0.3:
            return
    print(f"  PERINGATAN: narasi-{i} masih terlalu panjang, persingkat teksnya.")


async def main():
    for i, (text, limit) in enumerate(SCENES, 1):
        await make(i, text, limit)


asyncio.run(main())
