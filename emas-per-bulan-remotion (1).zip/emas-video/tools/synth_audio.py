"""Membuat musik latar & efek suara (WAV) tanpa file eksternal.
Jalankan: python3 tools/synth_audio.py   (butuh numpy)"""
import wave
import numpy as np

SR = 44100
OUT = "public/audio/"


def save(name, x):
    x = np.clip(x, -1, 1)
    if x.ndim == 1:
        x = np.stack([x, x], axis=1)
    pcm = (x * 32767).astype(np.int16)
    with wave.open(OUT + name, "wb") as w:
        w.setnchannels(2)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(pcm.tobytes())


def t_(d):
    return np.arange(int(SR * d)) / SR


def env(n, a=0.005, r=0.2):
    e = np.ones(n)
    na, nr = max(1, int(SR * a)), max(1, int(SR * r))
    e[:na] = np.linspace(0, 1, na)
    e[-nr:] = np.minimum(e[-nr:], np.linspace(1, 0, nr))
    return e


def tone(f, d, vol=0.3, decay=4.0, harm=(1, 0.4, 0.2)):
    t = t_(d)
    y = sum(h * np.sin(2 * np.pi * f * (i + 1) * t) for i, h in enumerate(harm))
    return y * np.exp(-decay * t) * vol * env(len(t), 0.004, 0.05)


def place(buf, y, at):
    i = int(at * SR)
    j = min(len(buf), i + len(y))
    buf[i:j] += y[: j - i]


def midi(n):
    return 440 * 2 ** ((n - 69) / 12)


# ---------- SFX ----------
def sfx_tap():
    t = t_(0.18)
    y = np.sin(2 * np.pi * 1200 * t) * np.exp(-35 * t) * 0.5
    y += np.sin(2 * np.pi * 1800 * t) * np.exp(-50 * t) * 0.25
    return y


def sfx_drop():  # klining koin emas
    b = np.zeros(int(SR * 0.9))
    for f, at, v in [(2093, 0, 0.4), (2637, 0.02, 0.3), (3136, 0.05, 0.22)]:
        place(b, tone(f, 0.8, v, 6, (1, 0.5, 0.25, 0.1)), at)
    place(b, tone(1568, 0.5, 0.25, 9), 0.12)
    place(b, tone(2349, 0.4, 0.2, 10), 0.15)
    return b


def flip_one(d=0.16):
    n = int(SR * d)
    noise = np.random.RandomState(1).randn(n)
    k = np.convolve(noise, np.ones(6) / 6, mode="same")
    e = np.exp(-np.arange(n) / (SR * d * 0.25))
    return k * e * 0.5


def sfx_flip():
    b = np.zeros(int(SR * 0.4))
    place(b, flip_one(), 0)
    return b


def sfx_flipfast():  # kalender berganti cepat (~3 detik)
    b = np.zeros(int(SR * 3.4))
    t = 0.0
    gap = 0.22
    while t < 3.0:
        place(b, flip_one(0.12) * (0.6 + 0.4 * (t / 3)), t)
        gap = max(0.07, gap * 0.93)
        t += gap
    return b


def sfx_shine():  # kilau emas muncul
    d = 3.0
    b = np.zeros(int(SR * d))
    notes = [72, 76, 79, 84, 88, 91, 96]
    for i, n in enumerate(notes):
        place(b, tone(midi(n), 1.6, 0.22, 2.6, (1, 0.3, 0.1)), i * 0.09)
    t = t_(d)
    sh = np.sin(2 * np.pi * midi(103) * t) * 0.05 * np.exp(-1.2 * t) * (1 + 0.5 * np.sin(2 * np.pi * 7 * t))
    b += sh
    # whoosh naik
    n = len(t)
    noise = np.random.RandomState(3).randn(n)
    wh = np.convolve(noise, np.ones(40) / 40, mode="same") * np.sin(np.pi * np.clip(t / 1.2, 0, 1)) * 0.25
    b += wh * (t < 1.2)
    return b


# ---------- Musik ----------
def music(d=30.0):
    n = int(SR * d)
    L = np.zeros(n)
    R = np.zeros(n)
    bar = 3.75  # 8 bar = 30 detik, tempo 64 bpm
    prog = [[48, 55, 64], [45, 52, 60], [53, 60, 69], [43, 50, 59]] * 2
    for i, ch in enumerate(prog):
        t0 = i * bar
        t = t_(bar + 0.8)
        pad = sum(np.sin(2 * np.pi * midi(m) * t) + 0.4 * np.sin(2 * np.pi * midi(m) * 2 * t + 0.3) for m in ch)
        pad = pad * 0.045 * env(len(t), 0.9, 0.9)
        place(L, pad, t0)
        place(R, pad * 0.9, t0 + 0.01)
        # arpeggio pluck (makin ramai)
        steps = [0, 1, 2, 1, 2, 1, 0, 2] if i >= 2 else [0, 2, 1, 2]
        sl = bar / len(steps)
        for k, s in enumerate(steps):
            note = ch[s] + 24
            y = tone(midi(note), 1.2, 0.07 + 0.012 * min(i, 5), 3.2, (1, 0.35, 0.12))
            place(L if k % 2 else R, y, t0 + k * sl)
            place(R if k % 2 else L, y * 0.5, t0 + k * sl)
        # bass lembut
        place(L, tone(midi(ch[0] - 12), bar, 0.12, 0.7, (1, 0.2)), t0)
        place(R, tone(midi(ch[0] - 12), bar, 0.12, 0.7, (1, 0.2)), t0)
    # lonceng di akhir
    for k, nn in enumerate([84, 88, 91]):
        y = tone(midi(nn), 2.5, 0.08, 1.8, (1, 0.3, 0.1))
        place(L, y, 27.2 + k * 0.12)
        place(R, y, 27.2 + k * 0.12)
    m = np.stack([L, R], axis=1)
    fade = np.ones(n)
    fi, fo = int(SR * 1.0), int(SR * 2.0)
    fade[:fi] = np.linspace(0, 1, fi)
    fade[-fo:] = np.linspace(1, 0, fo)
    m *= fade[:, None]
    return m / max(1e-9, np.abs(m).max()) * 0.9


if __name__ == "__main__":
    save("sfx-tap.wav", sfx_tap())
    save("sfx-drop.wav", sfx_drop())
    save("sfx-flip.wav", sfx_flip())
    save("sfx-flipfast.wav", sfx_flipfast())
    save("sfx-shine.wav", sfx_shine())
    save("music.wav", music())
    print("selesai")
